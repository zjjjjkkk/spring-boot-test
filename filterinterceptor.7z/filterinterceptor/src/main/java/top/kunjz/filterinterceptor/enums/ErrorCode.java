package top.kunjz.filterinterceptor.enums;

public class ErrorCode {
}
